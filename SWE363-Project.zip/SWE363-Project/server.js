const express = require('express');
const path = require('path');
const cors = require('cors');
const { connectDB, addUser, getUserByPhone } = require('./db.js'); // Ensure db.js has the required functions
const itemRoutes = require('./routes/itemRoutes'); // Import itemRoutes from the routes folder

// Connect to MongoDB
connectDB();

const app = express();
app.use('/Images',express.static('Images'));
app.use('/HTML',express.static('HTML'));
// Middleware
app.use(cors());
app.use(express.json()); // Parses incoming JSON requests
app.use(express.urlencoded({ extended: true })); // Parses URL-encoded requests

// Serve static files from the HTML folder
app.use(express.static(path.join(__dirname, 'HTML')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes to serve HTML pages
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'HTML', 'signIn.html'));
});

app.get('/resetPassword.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'HTML', 'resetPassword.html'));
});

app.get('/addItems.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'HTML', 'addItems.html'));
});

// Use item routes for /api/items
app.use('/api/items', itemRoutes);

// Handle user sign-in
const bcrypt = require('bcrypt'); // Import bcrypt

app.post('/api/signin', async (req, res) => {
    console.log('Sign-In route called');
    console.log('Sign-In Request Body:', req.body);

    const { phone, password } = req.body; // Extract phone and password from request body
    if (!phone || !password) {
        return res.status(400).json({ success: false, message: 'Phone number and password are required.' });
    }

    try {
        const user = await getUserByPhone(phone); // Fetch user from the database using the entered phone
        console.log('Entered Phone:', phone);
        console.log('Database Phone:', user ? user.phoneNumber : 'User not found');

        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found.' });
        }

        // Compare entered password with hashed password in the database
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            console.log('Incorrect Password');
            return res.status(401).json({ success: false, message: 'Incorrect password.' });
        }

        console.log(`User signed in successfully: ${phone}`);
        res.status(200).json({ success: true, message: 'Sign-in successful!', user });
    } catch (error) {
        console.error('Error during sign-in:', error.message);
        res.status(500).json({ success: false, message: 'An internal server error occurred.' });
    }
});

// Handle user registration
app.post('/api/users', async (req, res) => {
    console.log('User Registration Request:', req.body);

    try {
        const { firstName, lastName, phoneNumber, password } = req.body;
        if (!firstName || !lastName || !phoneNumber || !password) {
            return res.status(400).json({ success: false, message: 'All fields are required.' });
        }

        const user = await addUser(firstName, lastName, phoneNumber, password);
        console.log('User registered successfully:', user);
        res.status(201).json({ success: true, user });
    } catch (error) {
        console.error('Error during user registration:', error.message);
        res.status(500).json({ success: false, message: 'An internal server error occurred.' });
    }
});

// Handle Reset Password
app.post('/api/reset-password', async (req, res) => {
    console.log('Reset Password Request:', req.body);

    const { phoneNumber, newPassword } = req.body;

    if (!phoneNumber || !newPassword) {
        return res.status(400).json({ success: false, message: 'Phone number and new password are required.' });
    }

    try {
        const user = await getUserByPhone(phoneNumber);
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found.' });
        }

        // Hash the new password before saving it
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        user.password = hashedPassword;
        await user.save();

        console.log(`Password reset successful for user: ${phoneNumber}`);
        res.status(200).json({ success: true, message: 'Password reset successfully!' });
    } catch (error) {
        console.error('Error during password reset:', error.message);
        res.status(500).json({ success: false, message: 'An internal server error occurred.' });
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Error middleware:', err.message);
    res.status(500).json({ success: false, message: 'An internal server error occurred.' });
});

// Start the server
const PORT = process.env.PORT || 5002;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
