const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({
    itemName: { type: String, required: true },
    itemDescription: { type: String, required: true },
    category: { type: String, required: true },
    dateRange: { type: String, required: true },
    imageUrl: { type: String, required: true }, // Updated to match "imageUrl" from req.file
}, { timestamps: true });

module.exports = mongoose.models.Item || mongoose.model('Item', itemSchema);
