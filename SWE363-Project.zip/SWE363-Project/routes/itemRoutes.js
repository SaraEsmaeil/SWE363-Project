const express = require('express');
const Item = require('../models/itemModel');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const router = express.Router();

const dbFilePath = path.join(__dirname, '../Database.json'); // Correct path for JSON backup

// Configure Multer for file uploads
const upload = multer({
    dest: 'uploads/', // Directory to store uploaded files
    limits: { fileSize: 5 * 1024 * 1024 }, // Limit file size to 5MB
});

// Add a new item
router.post('/', upload.single('image'), async (req, res) => {
    console.log('Function called: POST /api/items'); // Log when the function is called
    console.log('Received POST /api/items request');
    console.log('Request Body:', req.body);
    console.log('Uploaded File Info:', req.file);

    const { itemName, itemDescription, category, dateRange } = req.body;
    const imageFile = req.file;
    // Validate required fields
    if (!itemName || !itemDescription || !category || !dateRange || !imageFile) {
        console.error('Validation failed: Missing required fields');
        return res.status(400).json({ success: false, message: 'All fields are required.' });
    }

    try {
        // Create a new Item instance
        const newItem = new Item({
            itemName,
            itemDescription,
            category,
            dateRange,
            imageUrl: imageFile.path, // Save the file path for the uploaded image
        });

        console.log('Creating new Item:', newItem);

        // Save the item to the database
        const savedItem = await newItem.save();

        console.log('Item saved to database:', savedItem);

        // Update or create the JSON file for backup
        const rawData = fs.existsSync(dbFilePath) ? fs.readFileSync(dbFilePath, 'utf-8') : '{}';
        const data = rawData.trim() ? JSON.parse(rawData) : { users: [], items: [], categories: [], notifications: [] };

        data.items.push(savedItem); // Add the saved item to the items array
        fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2), 'utf-8');

        console.log('Database.json updated successfully');

        // Respond with the saved item
        res.status(201).json({ success: true, message: 'Item added successfully!', item: savedItem });
    } catch (error) {
        console.error('Error saving item:', error.message);
        res.status(500).json({ success: false, message: 'Error saving item.', error: error.message });
    }
});

// Get all items
router.get('/', async (req, res) => {
    console.log('Function called: GET /api/items'); // Log when the function is called
    console.log('Received GET /api/items request');

    try {
        // Fetch all items from the database
        const items = await Item.find();

        console.log('Items fetched from database:', items);

        res.status(200).json({ success: true, items });
    } catch (error) {
        console.error('Error fetching items:', error.message);
        res.status(500).json({ success: false, message: 'Error fetching items.', error: error.message });
    }
});

// Get items by category
router.get('/category/:category', async (req, res) => {
    console.log('Function called: GET /api/items/category/:category'); // Log when the function is called
    const { category } = req.params;
    console.log(`Fetching items for category: ${category}`); // Log the category being fetched

    try {
        const items = await Item.find({ category }); // Fetch items based on category
        console.log(`Items fetched for category '${category}':`, items.length); // Log the number of items fetched
        res.status(200).json({ success: true, items });
    } catch (error) {
        console.error('Error fetching items:', error.message);
        res.status(500).json({ success: false, message: 'Error fetching items.' });
    }
});

module.exports = router;
