// Redirect to homepage after 5 seconds
setTimeout(() => {
    window.location.href = "homepage.html"; // Replace with your actual homepage link
}, 5000);
