const express = require('express');

const User = require('../models/usermodel');

const fs = require('fs');

const router = express.Router();

const dbFilePath = './Database.json';



// Add a new user

router.post('/', async (req, res) => {

  const { firstName, lastName, phoneNumber, password } = req.body;



  if (!firstName || !lastName || !phoneNumber || !password) {

    return res.status(400).json({ message: 'All fields are required' });

  }



  try {

    const newUser = new User({ firstName, lastName, phoneNumber, password });

    const savedUser = await newUser.save();



    // Update JSON file

    const rawData = fs.existsSync(dbFilePath) ? fs.readFileSync(dbFilePath, 'utf-8') : '{}';

    const data = rawData.trim() ? JSON.parse(rawData) : { users: [], items: [], categories: [], notifications: [] };

    data.users.push(savedUser);

    fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2), 'utf-8');



    res.status(201).json(savedUser);

  } catch (error) {

    res.status(500).json({ message: 'Error saving user', error: error.message });

  }

});



// Get all users

router.get('/', async (req, res) => {

  try {

    const users = await User.find();

    res.json(users);

  } catch (error) {

    res.status(500).json({ message: 'Error fetching users', error: error.message });

  }

});



module.exports = router;