// JavaScript for any interactive elements (if needed)

document.querySelector('.close-btn').addEventListener('click', function() {
    alert('Close button clicked');
});
