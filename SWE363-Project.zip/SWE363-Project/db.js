const mongoose = require('mongoose');
const bcrypt = require('bcrypt'); // Import bcrypt for hashing

// Define User schema and model
const userSchema = new mongoose.Schema({
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  phoneNumber: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});

const User = mongoose.models.User || mongoose.model('User', userSchema);

// Define Item schema and model
const itemSchema = new mongoose.Schema({
  itemName: { type: String, required: true },
  itemDescription: { type: String, required: true },
  category: { type: String, required: true },
  dateRange: { type: String, required: true },
  imageUrl: { type: String, required: true },
});

const Item = mongoose.models.Item || mongoose.model('Item', itemSchema);

// Connect to MongoDB
const connectDB = async () => {
  try {
    const conn = await mongoose.connect('mongodb://127.0.0.1:27017/database_json');
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error('Error connecting to MongoDB:', error.message);
    process.exit(1);
  }
};

// Add a new user with hashed password
const addUser = async (firstName, lastName, phoneNumber, password) => {
  try {
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10); // 10 is the salt rounds
    const newUser = new User({ firstName, lastName, phoneNumber, password: hashedPassword });
    const savedUser = await newUser.save();
    console.log('User saved:', savedUser);
    return savedUser;
  } catch (error) {
    console.error('Error saving user:', error.message);
    throw error;
  }
};

// Get user by phone number
const getUserByPhone = async (phoneNumber) => {
  try {
    const user = await User.findOne({ phoneNumber });
    if (!user) {
      console.log('User not found for phone number:', phoneNumber);
    }
    return user;
  } catch (error) {
    console.error('Error fetching user by phone number:', error.message);
    throw error;
  }
};

// Add a new item
const addItem = async (itemName, itemDescription, category, dateRange, imageUrl) => {
  try {
    const newItem = new Item({ itemName, itemDescription, category, dateRange, imageUrl });
    const savedItem = await newItem.save();
    console.log('Item saved:', savedItem);
    return savedItem;
  } catch (error) {
    console.error('Error saving item:', error.message);
    throw error;
  }
};

// Get all items
const getItems = async () => {
  try {
    const items = await Item.find({});
    return items;
  } catch (error) {
    console.error('Error fetching items:', error.message);
    throw error;
  }
};

module.exports = { connectDB, addUser, getUserByPhone, addItem, getItems };
