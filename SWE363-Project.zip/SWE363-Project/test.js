const mongoose = require('mongoose');

// Define a simple schema and model
const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    age: Number,
});

const User = mongoose.model('User', userSchema);

// Function to connect to MongoDB
const connectDB = async () => {
    try {
        await mongoose.connect('mongodb://127.0.0.1:27017/testDB');
        console.log('Connected to MongoDB successfully!');
    } catch (err) {
        console.error('MongoDB connection error:', err.message);
        process.exit(1); // Exit process if connection fails
    }
};

// Function to insert a sample user
const addUser = async () => {
    try {
        const user = new User({
            name: 'John Doe',
            email: 'john.doe@example.com',
            age: 30,
        });

        const savedUser = await user.save();
        console.log('User added:', savedUser);
    } catch (err) {
        console.error('Error adding user:', err.message);
    }
};

// Run the script
const run = async () => {
    await connectDB();
    await addUser();
    mongoose.connection.close(); // Close connection after operations
};

run();
